import 'package:flutter/material.dart';
class ShoppingCartPage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('Shopping Cart'),
    );
  }
}
